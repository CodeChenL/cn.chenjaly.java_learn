package cn.chenjaly.app;

import cn.chenjaly.service.ShowView;

public class ShowApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ShowView sView =  new ShowView();
		sView.ShopStart();
	}

}
